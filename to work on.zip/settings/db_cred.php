<?php
//Database credentials
// Settings/db_cred.php

// define('DB_HOST', 'localhost');
// define('DB_USER', 'akua.amofa');
// define('DB_PASS', '');
// define('DB_NAME', 'ecommerce_2025A_akua_amofa');

if (!defined("SERVER")) {
    define("SERVER", "localhost");
}

if (!defined("USERNAME")) {
    define("USERNAME", "akua.amofa");
}

if (!defined("PASSWD")) {
    define("PASSWD", "newsql@pass");
}

if (!defined("DATABASE")) {
    define("DATABASE", "ecommerce_2025A_akua_amofa");
}
?>